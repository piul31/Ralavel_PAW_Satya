<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('index');
});*/

Route::get('/', 'App\Http\Controllers\MainController@home');
Route::get('/students', '\App\Http\Controllers\StudentsController@index');
Route::get('/students/create', '\App\Http\Controllers\StudentsController@create');
Route::get('/students/{student}', '\App\Http\Controllers\StudentsController@show');
Route::post('/students', '\App\Http\Controllers\StudentsController@store');
Route::delete('/students/{student}', '\App\Http\Controllers\StudentsController@destroy');
Route::get('/students/{student}/edit', '\App\Http\Controllers\StudentsController@edit');
Route::patch('/students/{student}', '\App\Http\Controllers\StudentsController@update');
