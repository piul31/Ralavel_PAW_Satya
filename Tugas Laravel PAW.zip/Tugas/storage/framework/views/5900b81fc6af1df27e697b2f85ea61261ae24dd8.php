
<?php $__env->startSection('title', 'Form Data Mahasiswa'); ?>
<?php $__env->startSection('container'); ?>
<div class="container">
<div class="row">
<div class="col-8">
    <h1 class="mt-3">Form Data Mahasiswa</h1>
   <form method="POST" action="/students">
   <?php echo csrf_field(); ?>
       <div class="form-group">
           <label for="nama">Nama</label>
           <input type="text" class="form-control" id="nama" placeholder="Masukkan Nama" name="nama" required>
       </div>
       <div class="form-group">
           <label for="nim">NIM</label>
           <input type="text" class="form-control" id="nim" placeholder="Masukkan NIM" name="nim" required>
       </div>
       <div class="form-group">
           <label for="prodi">Prodi</label>
           <input type="text" class="form-control" id="prodi" placeholder="Masukkan Prodi" name="prodi" required>
       </div>
       <button type="submit" class="btn btn-primary">Simpan</button>
   </form>
</div></div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas\resources\views/students/create.blade.php ENDPATH**/ ?>