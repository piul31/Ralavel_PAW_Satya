
<?php $__env->startSection('title', 'Form Ubah Data Mahasiswa'); ?>
<?php $__env->startSection('container'); ?>
<div class="container">
<div class="row">
<div class="col-8">
    <h1 class="mt-3">Form Ubah Data Mahasiswa</h1>
   <form method="POST" action="/students/<?php echo e($student->id); ?>">
    <?php echo method_field('patch'); ?>
   <?php echo csrf_field(); ?>
       <div class="form-group">
           <label for="nama">Nama</label>
           <input type="text" class="form-control" id="nama" placeholder="Masukkan Nama" name="nama" value="<?php echo e($student->nama); ?>" required>
       </div>
       <div class="form-group">
           <label for="nim">NIM</label>
           <input type="text" class="form-control" id="nim" placeholder="Masukkan NIM" name="nim" value="<?php echo e($student->nim); ?>" required>
       </div>
       <div class="form-group">
           <label for="prodi">Prodi</label>
           <input type="text" class="form-control" id="prodi" placeholder="Masukkan Prodi" name="prodi" value="<?php echo e($student->prodi); ?>" required>
       </div>
       <button type="submit" class="btn btn-primary">Simpan</button>
   </form>
</div></div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas\resources\views/students/edit.blade.php ENDPATH**/ ?>