
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('container'); ?>
<div class="container">
<div class="row">
<div class="col-10">
    <h1 class="mt-3">Tugas PAW</h1>
    <h2>Membuat daftar mahasiswa dengan Laravel</h2>
</div></div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas\resources\views/index.blade.php ENDPATH**/ ?>